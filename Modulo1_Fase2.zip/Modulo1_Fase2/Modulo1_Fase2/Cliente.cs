﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo1_Fase2
{
    class Cliente
    {
        public int idCliente { get; set; }
        public string nomeCliente { get; set; }
        public string enderecoCliente { get; set; }
        public string telefoneCliente { get; set; }
        public string filiacaoCliente { get; set; }
        public string statusCliente { get; set; }
        public double limiteCreditoCliente { get; set; }

        public Cliente(int idcliente, string nomecliente, string enderecocliente, string telefonecliente, string filiacaocliente, string statuscliente, double limitecreditocliente)
        {
            idCliente = idcliente;
            nomeCliente = nomecliente;
            enderecoCliente = enderecocliente;
            telefoneCliente = telefonecliente;
            filiacaoCliente = filiacaocliente;
            statusCliente = statuscliente;
            limiteCreditoCliente = limitecreditocliente;
        }
    }
}
