﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo1_Fase2
{
    class Fornecedor
    {
        public int CNPJ { get; set; }
        public string nomeFantasia { get; set; }
        public string telefone { get; set; }
        public string endereco { get; set; }
        public string email { get; set; }

        public Fornecedor(int cnpj, string nomefantasia, string telefone, string endereco, string email)
        {
            CNPJ = cnpj;
            nomeFantasia = nomefantasia;
            this.telefone = telefone;
            this.endereco = endereco;
            this.email = email;
        }


    }
}
