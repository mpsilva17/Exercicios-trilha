﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo1_Fase2
{
    class Produto
    {
        public int idProduto { get; set; }
        public string nomeProduto { get; set; }
        public Categoria categoria { get; set; }
        public DateTime dataFabricacao { get; set; }
        public DateTime dataVencimento { get; set; }
        public double precoUnitario { get; set; }
        public Fornecedor fornecedor { get; set; }

        public Produto(int idproduto, string nomeproduto, Categoria categoria, DateTime datafabricacao, DateTime datavencimento, double precounitario, Fornecedor fornecedor)
        {
            idProduto = idproduto;
            nomeProduto = nomeproduto;
            this.categoria = categoria;
            dataFabricacao = datafabricacao;
            dataVencimento = datavencimento;
            precoUnitario = precounitario;
            this.fornecedor = fornecedor;
        }

    }
}
