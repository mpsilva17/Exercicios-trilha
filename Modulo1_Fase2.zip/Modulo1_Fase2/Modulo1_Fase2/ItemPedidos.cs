﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo1_Fase2
{
    class ItemPedidos
    {
        private Pedido pedido { get; set; }
        public Produto produto { get; set; }
        public int quantidadeProdutos { get; set; }
        public double valorTotalItem { get; set; }

        public ItemPedidos(Pedido pedido, Produto produto, int qtdprodutos)
        {
            this.pedido = pedido;
            this.produto = produto;
            quantidadeProdutos = qtdprodutos;
            valorTotalItem = produto.precoUnitario * qtdprodutos;

            
            pedido.CalcularTotalPedido(valorTotalItem);
            
        }


        


    }
}
