﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo1_Fase2
{
    class Program
    {
        static void Main(string[] args)
        {
            //CATEGORIAS
            Categoria legume = new Categoria(1, "Legume");
            Categoria congelado = new Categoria(2, "Congelado");

            //FORNECEDORES
            Fornecedor fornecedor1 = new Fornecedor(123456789, "Fornecedor 1", "91234-5678", "Rua Três", "fornecedor1@gmail.com");

            //CLIENTES
            Cliente marcos = new Cliente(1, "Marcos", "Rua Monteiro", "99372-2220", "Filiação 1", "Status 1", 100.0);
            Cliente paulo = new Cliente(1, "Paulo", "Rua Cardoso", "99372-2228", "Filiação 2", "Status 2", 1000.0);


            //PRODUTOS
            Produto batata = new Produto(1, "Batata", legume, Convert.ToDateTime("01/08/2019"), DateTime.Now, 4.00, fornecedor1);
            Produto pizza = new Produto(2, "Pizza", congelado, Convert.ToDateTime("01/08/2019"), DateTime.Now, 15.75, fornecedor1);
            Produto sorvete = new Produto(3, "Pizza", congelado, Convert.ToDateTime("01/08/2019"), DateTime.Now, 10.99, fornecedor1);

            //PEDIDOS
            Pedido pedidoDoMarcos = new Pedido(1, DateTime.Now, marcos);
            Pedido pedidoDoPaulo = new Pedido(2, DateTime.Now, paulo);

            //ITENS DOS PEDIDOS
            ItemPedidos item1 = new ItemPedidos(pedidoDoMarcos, batata, 10);
            ItemPedidos item2 = new ItemPedidos(pedidoDoMarcos, pizza, 1);
            ItemPedidos item3 = new ItemPedidos(pedidoDoPaulo, sorvete, 2);


            Console.WriteLine(pedidoDoMarcos.FechamentoPedido());

            Console.ReadKey();

        }
    }
}
