﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modulo1_Fase2
{
    class Pedido
    {
        public int idPedido { get; set; }
        public DateTime dataElaboracao { get; set; }
        public double valorTotalPedido { get; set ; }
        public Cliente cliente { get; set; }

        public Pedido(int idpedido, DateTime dtelaboracao, Cliente cliente)
        {
            idPedido = idpedido;
            dataElaboracao = dtelaboracao;
            this.cliente = cliente;
            valorTotalPedido = 0;
        }

        public void CalcularTotalPedido(double valorItem)
        {
            valorTotalPedido += valorItem;
        }

        public bool SaldoClienteESuficiente()
        {
            if (valorTotalPedido > cliente.limiteCreditoCliente)
            {
                return false;
            }

            return true;
        }

        public string FechamentoPedido()
        {
            string msg = "Fechamento do pedido: \n"
                       + "\nData elaboração: " + dataElaboracao
                       + "\nValor total: R$ " + valorTotalPedido.ToString("F")
                       + "\nCliente: " + cliente.nomeCliente;

            if (!SaldoClienteESuficiente())
            {
                msg = "\nSaldo Insuficiente para fechamento do pedido";
                return msg;
            }

            return msg;

        }

        

    }
}
